const $ = (s) => document.querySelector(s);
const chat = $('#chat'), logs = $('#logs'), orb = $('#orb'), micBtn = $('#micBtn'), statusEl = $('#status');
const alarmBtn = $('#alarmBtn'), stopAlarmBtn = $('#stopAlarmBtn'), alarmBanner = $('#alarmBanner');
let ws = null, mediaRecorder = null, reconnectTimer = null, listening = false;

function log(x){ logs.textContent += `[${new Date().toLocaleTimeString()}] ${x}\n`; logs.scrollTop = logs.scrollHeight; }
function addMsg(role,text){ if(!text || text==='__STOP__') return; const d=document.createElement('div'); d.className=`msg ${role}`; d.textContent=text; chat.appendChild(d); chat.scrollTop=chat.scrollHeight; }
function state(s){ listening=s==='listening'; orb.classList.toggle('listening',listening); micBtn.classList.toggle('is-listening',listening); statusEl.textContent=s; }
function setAlarm(active,reason='',sentTo=[],location=null){
  document.body.classList.toggle('alarm-active',active); alarmBanner.hidden=!active; alarmBtn.textContent=active?'ТРЕВОГА ВКЛ.':'ТРЕВОГА';
  if(active){
    const who=sentTo?.length?` Отправлено: ${sentTo.join(', ')}.`:'';
    $('#alarmInfo').textContent=(reason||'JARVIS на связи.')+who;
    $('#alarmLocation').textContent=location?.maps_url ? `Последняя геопозиция: ${location.maps_url}` : 'Геопозиция ещё не получена';
    log(`ALARM: ${reason||'активирован'}${who}`);
  } else log('ALARM: отключён');
}
function connect(){
  if(ws&&(ws.readyState===0||ws.readyState===1)) return;
  const proto=location.protocol==='https:'?'wss':'ws'; ws=new WebSocket(`${proto}://${location.host}/ws`);
  ws.onopen=()=>{statusEl.textContent='online';log('WebSocket подключён');clearTimeout(reconnectTimer)};
  ws.onclose=()=>{statusEl.textContent='offline';log('WebSocket отключён');reconnectTimer=setTimeout(connect,2000)};
  ws.onerror=()=>log('WebSocket error');
  ws.onmessage=e=>{ const m=JSON.parse(e.data); if(m.type==='state')state(m.state); if(m.type==='assistant')addMsg('assistant',m.text); if(m.type==='alarm')setAlarm(!!m.active,m.reason,m.sent_to||[],m.location); };
}
async function send(text){
  text=text.trim(); if(!text)return; addMsg('user',text);
  if(ws?.readyState===1){ws.send(JSON.stringify({type:'command',text}));return;}
  try{const r=await fetch('/api/command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text})});const x=await r.json();addMsg('assistant',x.answer);if(x.alarm)setAlarm(x.alarm.active,x.alarm.reason,x.alarm.sent_to,x.alarm.location)}catch(e){log(`command: ${e.message}`)}
}
async function alarm(start){
  try{ if(ws?.readyState===1){ws.send(JSON.stringify({type:start?'alarm_start':'alarm_stop'}));return;} const r=await fetch(start?'/api/alarm/start':'/api/alarm/stop',{method:'POST'}); const x=await r.json(); addMsg('assistant',x.message); if(x.alarm)setAlarm(x.alarm.active,x.alarm.reason,x.alarm.sent_to,x.alarm.location); }catch(e){log(`alarm: ${e.message}`)}
}
async function loadAlarmSettings(){
  const r=await fetch('/api/alarm/settings'); const x=await r.json();
  $('#alarmEnabled').checked=x.enabled; $('#sendLocation').checked=x.send_location; $('#alarmMessage').value=x.message; $('#repeatMinutes').value=x.repeat_minutes; $('#locationRefreshMinutes').value=x.location_refresh_minutes; $('#sendRecovery').checked=x.send_recovery_message; $('#recoveryMessage').value=x.recovery_message;
}
async function saveAlarmSettings(){
  const body={enabled:$('#alarmEnabled').checked,send_location:$('#sendLocation').checked,message:$('#alarmMessage').value,repeat_minutes:Number($('#repeatMinutes').value),location_refresh_minutes:Number($('#locationRefreshMinutes').value),send_recovery_message:$('#sendRecovery').checked,recovery_message:$('#recoveryMessage').value};
  const r=await fetch('/api/alarm/settings',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); if(r.ok)addMsg('assistant','Настройки тревоги сохранены.');else log('Не удалось сохранить настройки тревоги');
}
async function loadContacts(){
  const r=await fetch('/api/contacts'); const cs=await r.json(); const box=$('#contacts'); box.innerHTML='';
  if(!cs.length){box.innerHTML='<div class="empty">Пока нет экстренных контактов.</div>';return;}
  cs.forEach(c=>{const d=document.createElement('div');d.className='contact';d.innerHTML=`<div><b>${esc(c.name)}</b><span>${esc(c.phone)}</span></div><label class="mini-switch"><input type="checkbox" ${c.enabled?'checked':''}><span>получает тревогу</span></label><button class="delete">Удалить</button>`;d.querySelector('input').onchange=()=>fetch(`/api/contacts/${c.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled:d.querySelector('input').checked})});d.querySelector('.delete').onclick=async()=>{await fetch(`/api/contacts/${c.id}`,{method:'DELETE'});loadContacts()};box.appendChild(d)})
}
function esc(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
$('#connectBtn').onclick=connect; alarmBtn.onclick=()=>alarm(true); stopAlarmBtn.onclick=()=>alarm(false); $('#saveAlarmSettings').onclick=saveAlarmSettings;
$('#commandForm').onsubmit=e=>{e.preventDefault();const v=$('#command');send(v.value);v.value=''};
document.querySelectorAll('[data-cmd]').forEach(b=>b.onclick=()=>send(b.dataset.cmd));
document.querySelectorAll('[data-routine]').forEach(b=>b.onclick=()=>send(`Джарвис, ${b.dataset.routine}`));
$('#contactForm').onsubmit=async e=>{e.preventDefault();const body={name:$('#contactName').value,phone:$('#contactPhone').value,enabled:true};const r=await fetch('/api/contacts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(r.ok){$('#contactName').value='';$('#contactPhone').value='';loadContacts()}else{const x=await r.json();addMsg('assistant',x.detail||'Не удалось добавить контакт')}};

async function startMic(){
  if(!navigator.mediaDevices?.getUserMedia){log('Браузер не поддерживает microphone API');return}
  const stream=await navigator.mediaDevices.getUserMedia({audio:true});
  mediaRecorder=new MediaRecorder(stream); mediaRecorder.onstop=()=>stream.getTracks().forEach(t=>t.stop()); mediaRecorder.start(); state('listening');
  log('Микрофон активен. Для постоянного wake-word в APK будет использоваться Android foreground service + Vosk.');
}
function stopMic(){if(mediaRecorder?.state==='recording')mediaRecorder.stop();state('idle')}
micBtn.onclick=()=>listening?stopMic():startMic().catch(e=>log(`mic: ${e.message}`));

connect();
Promise.all([loadAlarmSettings(),loadContacts(),fetch('/api/alarm').then(r=>r.json()).then(x=>setAlarm(x.active,x.reason,x.sent_to||[],x.location))]).catch(e=>log(e.message));
