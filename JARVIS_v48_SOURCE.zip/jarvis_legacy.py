#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""JARVIS v30: Russian Vosk wake-word assistant for Termux.
Safe voice actions only; no arbitrary shell commands from voice.
Wake words: шатрик, шарик, шатрикс, джарвис
"""
import json, os, re, sqlite3, subprocess, sys, time
from pathlib import Path

APP=Path.home()/"jarvis"
MODEL=APP/"model-ru"
DB=APP/"jarvis_memory.db"
RATE=16000
WAKE=("шатрик","шарик","шатрикс","джарвис")


def cmd(args, timeout=20):
    try:
        p=subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
        return p.returncode,p.stdout.strip(),p.stderr.strip()
    except Exception as e: return 1,"",str(e)


def speak(text):
    text=str(text).replace("\n"," ").strip()
    if text:
        print("JARVIS:",text)
        cmd(["termux-tts-speak","-l","ru-RU","-r","0.95",text],20)


def db_init():
    APP.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(DB); c=con.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS memory (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id TEXT, role TEXT, content TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
    c.execute("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
    con.commit(); con.close()


def remember(role,content):
    con=sqlite3.connect(DB); con.execute("INSERT INTO memory(chat_id,role,content) VALUES(?,?,?)",("local",role,content)); con.commit(); con.close()


def note(s):
    con=sqlite3.connect(DB); con.execute("INSERT INTO notes(content) VALUES(?)",(s,)); con.commit(); con.close()


def battery():
    rc,out,_=cmd(["termux-battery-status"])
    if rc!=0:return "Не удалось получить состояние батареи."
    try:
        d=json.loads(out); return f"Заряд батареи {d.get('percentage','?')} процентов. Состояние: {d.get('status','неизвестно')}."
    except:return "Не удалось прочитать данные батареи."


def music():
    for x in (["am","start","--user","0","-a","android.intent.action.MAIN","-c","android.intent.category.LAUNCHER","-p","ru.yandex.music"],["monkey","-p","ru.yandex.music","-c","android.intent.category.LAUNCHER","1"]):
        rc,_,_=cmd(x,15)
        if rc==0:return "Включаю Яндекс Музыку."
    return "Не смог открыть Яндекс Музыку. Проверь, что приложение установлено."


def alarm(t):
    m=re.search(r"\b([01]?\d|2[0-3])[:.]([0-5]\d)\b",t)
    if m:h,mi=int(m.group(1)),int(m.group(2))
    else:
        m=re.search(r"(?:на|в)\s+(\d{1,2})(?:\s*(?:час(?:а|ов)?\s*)?(\d{2}))?",t)
        if not m:return "Не понял время. Скажи: поставь будильник на семь тридцать или на 7:30."
        h,mi=int(m.group(1)),int(m.group(2) or 0)
    if not(0<=h<=23 and 0<=mi<=59):return "Время указано неправильно."
    rc,_,_=cmd(["am","start","-a","android.intent.action.SET_ALARM","--es","android.intent.extra.alarm.MESSAGE","Шатрик","--ei","android.intent.extra.alarm.HOUR",str(h),"--ei","android.intent.extra.alarm.MINUTES",str(mi),"--ez","android.intent.extra.alarm.SKIP_UI","true"],15)
    return f"Будильник на {h:02d}:{mi:02d} установлен." if rc==0 else "Android не разрешил установить будильник без открытия часов."


def stripwake(t):
    for w in WAKE:t=re.sub(rf"\b{re.escape(w)}\b"," ",t,flags=re.I)
    return re.sub(r"\s+"," ",t).strip()


def process(t):
    t=stripwake(t.lower())
    if not t:return "Слушаю, сэр."
    if any(x in t for x in ("включи музыку","яндекс музыку","яндекс музыка","открой музыку","запусти музыку","открой яндекс")):return music()
    if any(x in t for x in ("будильник","разбуди меня","поставь будильник")):return alarm(t)
    if any(x in t for x in ("батарея","заряд","аккумулятор")):return battery()
    if any(x in t for x in ("запиши","запомни","сделай заметку","в заметки")):
        s=re.sub(r"\b(запиши|запомни|сделай заметку|в заметки)\b","",t).strip()
        if not s:return "Что именно записать?"
        note(s);return f"Записал: {s}."
    if t in ("привет","здравствуй","здарова","здаров","ку","хай"):return "Здравия желаю, сэр. Я слушаю."
    if t in ("остановись","выключись","спать","хватит"):return "__STOP__"
    return "Команду понял, но это действие пока не добавлено в безопасный список."


def record(path,seconds):
    Path(path).unlink(missing_ok=True)
    rc,_,_=cmd(["termux-microphone-record","-f",str(path),"-l",str(seconds),"-r",str(RATE),"-c","1"],seconds+10)
    return rc==0 and Path(path).exists() and Path(path).stat().st_size>1000


def recognize(path,model,vosk):
    import wave
    try:
        wf=wave.open(str(path),"rb")
        if wf.getnchannels()!=1 or wf.getsampwidth()!=2: wf.close();return ""
        r=vosk.KaldiRecognizer(model,wf.getframerate())
        while True:
            d=wf.readframes(4000)
            if not d:break
            r.AcceptWaveform(d)
        s=json.loads(r.FinalResult()).get("text","").strip();wf.close();return s
    except Exception as e:print("[VOSK]",e);return ""


def haswake(t):return any(re.search(rf"\b{re.escape(w)}\b",t,re.I) for w in WAKE)


def main():
    db_init()
    try:import vosk
    except ImportError:
        print("Vosk не установлен. Выполни: pip install vosk");sys.exit(1)
    if not MODEL.exists():
        print("Нет русской модели:",MODEL);print("Запусти install_jarvis.sh");sys.exit(1)
    model=vosk.Model(str(MODEL)); tmp=APP/"voice_chunk.wav"
    cmd(["termux-wake-lock"],5)
    print("="*55);print('JARVIS v30 — скажи «Шатрик»');print("Ctrl+C — выход");print("="*55)
    speak("Шатрик активирован. Я слушаю.")
    try:
        while True:
            if not record(tmp,2):time.sleep(1);continue
            heard=recognize(tmp,model,vosk)
            if heard:print("Распознано:",heard)
            if not haswake(heard):continue
            command=stripwake(heard)
            if not command:
                speak("Слушаю, сэр.")
                if record(tmp,6):command=recognize(tmp,model,vosk)
            if not command:speak("Не расслышал команду.");continue
            print("Команда:",command);remember("user",command)
            ans=process(command)
            if ans=="__STOP__":speak("Переходжу в режим ожидания.");break
            remember("assistant",ans);speak(ans)
    except KeyboardInterrupt:print("\nВыход.")
    finally:cmd(["termux-wake-unlock"],5)

if __name__=="__main__":main()
