# JARVIS v48

Пакет для сборки Android APK.

- Android project: `android/`
- Automated build: `.github/workflows/android-build.yml`
- Build guide: `BUILD_APK.md`
- Version: 48.0

В этой среде готовые APK не создавались, потому что отсутствуют Android SDK/Gradle и недоступны репозитории зависимостей. Workflow собирает Debug и тестово-подписанный Release на GitHub Actions.
