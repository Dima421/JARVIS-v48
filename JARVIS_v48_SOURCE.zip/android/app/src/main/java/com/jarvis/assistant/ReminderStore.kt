package com.jarvis.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ReminderStore {
    private const val PREFS = "jarvis_reminders"
    private const val KEY = "items"

    data class Item(val id: Long, val title: String, val triggerAt: Long, val kind: String)

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun add(context: Context, item: Item) {
        val old = all(context).filter { it.id != item.id }
        val arr = JSONArray()
        (old + item).sortedBy { it.triggerAt }.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("title", it.title); put("triggerAt", it.triggerAt); put("kind", it.kind)
            })
        }
        prefs(context).edit().putString(KEY, arr.toString()).apply()
    }

    @Synchronized fun remove(context: Context, id: Long) {
        val arr = JSONArray()
        all(context).filter { it.id != id }.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("title", it.title); put("triggerAt", it.triggerAt); put("kind", it.kind)
            })
        }
        prefs(context).edit().putString(KEY, arr.toString()).apply()
    }

    fun all(context: Context): List<Item> {
        val raw = prefs(context).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(Item(o.getLong("id"), o.getString("title"), o.getLong("triggerAt"), o.getString("kind")))
                }
            }
        }.getOrDefault(emptyList())
    }
}
