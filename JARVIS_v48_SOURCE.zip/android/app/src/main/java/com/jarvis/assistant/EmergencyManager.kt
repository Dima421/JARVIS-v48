package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

object EmergencyManager {
    private const val PREF = "jarvis_emergency"
    private const val KEY_CONTACTS = "contacts"

    data class Contact(val id: Long, val name: String, val phone: String)

    fun contacts(context: Context): List<Contact> = runCatching {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_CONTACTS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        buildList { for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); add(Contact(o.getLong("id"), o.getString("name"), o.getString("phone"))) } }
    }.getOrDefault(emptyList())

    fun contactsJson(context: Context): String = JSONArray().apply {
        contacts(context).forEach { c -> put(JSONObject().apply { put("id", c.id); put("name", c.name); put("phone", c.phone) }) }
    }.toString()

    fun add(context: Context, name: String, phone: String): String {
        val clean = phone.trim()
        if (clean.isBlank()) return "Укажи номер телефона."
        val list = contacts(context).toMutableList()
        if (list.any { it.phone == clean }) return "Этот номер уже добавлен."
        list.add(Contact(System.currentTimeMillis(), name.trim().ifBlank { "Контакт" }, clean))
        save(context, list)
        return "Контакт добавлен."
    }

    fun remove(context: Context, id: Long): String {
        val list = contacts(context).filterNot { it.id == id }
        save(context, list)
        return "Контакт удалён."
    }

    private fun save(context: Context, list: List<Contact>) {
        val arr = JSONArray().apply { list.forEach { c -> put(JSONObject().apply { put("id", c.id); put("name", c.name); put("phone", c.phone) }) } }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_CONTACTS, arr.toString()).apply()
    }

    fun activate(context: Context): String {
        val list = contacts(context)
        if (list.isEmpty()) return "Тревожный режим не настроен: добавь хотя бы один контакт."
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return "Нужен доступ к SMS. Разреши его в настройках JARVIS."
        val location = lastKnownLocation(context)
        val locationText = if (location != null) {
            val lat = String.format(Locale.US, "%.6f", location.latitude)
            val lon = String.format(Locale.US, "%.6f", location.longitude)
            "\nМоя геопозиция: https://maps.google.com/?q=$lat,$lon"
        } else "\nГеопозицию получить не удалось."
        val message = "JARVIS: Я в опасности. Нужна помощь. Я на связи.$locationText"
        val sms = SmsManager.getDefault()
        list.forEach { c -> runCatching { sms.sendTextMessage(c.phone, null, message, null, null) } }
        NotificationHelper.showGeneral(context, "JARVIS — тревога", "Сообщение отправлено ${list.size} контакт(ам).")
        return "Тревога активирована. Сообщение отправлено ${list.size} контакт(ам)."
    }

    private fun lastKnownLocation(context: Context): Location? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getProviders(true).asSequence().mapNotNull { provider -> runCatching { lm.getLastKnownLocation(provider) }.getOrNull() }.maxByOrNull { it.time }
    }
}
