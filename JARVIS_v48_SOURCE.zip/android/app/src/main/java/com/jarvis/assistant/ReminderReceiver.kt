package com.jarvis.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE) ?: "Напоминание JARVIS"
        val id = intent.getLongExtra(ReminderScheduler.EXTRA_ID, 0L)
        val kind = intent.getStringExtra(ReminderScheduler.EXTRA_KIND) ?: "reminder"
        val heading = when (kind) {
            "timer" -> "Таймер JARVIS"
            "alarm" -> "Будильник JARVIS"
            else -> "Напоминание JARVIS"
        }
        NotificationHelper.show(context, heading, title, id.toInt())
        if (id != 0L) ReminderStore.remove(context, id)
    }
}
