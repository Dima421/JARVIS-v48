package com.jarvis.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReminderScheduler {
    const val EXTRA_TITLE = "title"
    const val EXTRA_ID = "id"
    const val EXTRA_KIND = "kind"
    const val ACTION_REMINDER = "com.jarvis.assistant.REMINDER"
    data class Scheduled(val id: Long, val title: String, val triggerAt: Long, val kind: String)

    fun schedule(context: Context, title: String, triggerAt: Long, kind: String = "reminder"): Scheduled {
        val id = ((System.currentTimeMillis() and 0x7fffffffL) + (0..999).random()).coerceAtMost(Int.MAX_VALUE.toLong())
        scheduleWithId(context, id, title, triggerAt, kind)
        ReminderStore.add(context, ReminderStore.Item(id, title, triggerAt, kind))
        return Scheduled(id, title, triggerAt, kind)
    }

    fun scheduleWithId(context: Context, id: Long, title: String, triggerAt: Long, kind: String) {
        if (triggerAt <= System.currentTimeMillis()) return
        val intent = Intent(context, ReminderReceiver::class.java).apply { action = ACTION_REMINDER; putExtra(EXTRA_TITLE, title); putExtra(EXTRA_ID, id); putExtra(EXTRA_KIND, kind) }
        val pi = PendingIntent.getBroadcast(context, id.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = context.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        else am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
    }

    fun cancel(context: Context, id: Long) {
        val intent = Intent(context, ReminderReceiver::class.java).apply { action = ACTION_REMINDER }
        val pi = PendingIntent.getBroadcast(context, id.toInt(), intent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pi != null) context.getSystemService(AlarmManager::class.java).cancel(pi)
        ReminderStore.remove(context, id)
    }

    fun restoreAll(context: Context) {
        val now = System.currentTimeMillis()
        ReminderStore.all(context).filter { it.triggerAt > now }.forEach { scheduleWithId(context, it.id, it.title, it.triggerAt, it.kind) }
    }

    fun summary(context: Context?): String {
        if (context == null) return "Открой список в приложении, чтобы увидеть запланированные события."
        val fmt = SimpleDateFormat("dd.MM HH:mm", Locale("ru"))
        val items = ReminderStore.all(context).filter { it.triggerAt > System.currentTimeMillis() }.sortedBy { it.triggerAt }.take(8)
        if (items.isEmpty()) return "Запланированных событий нет."
        return "Ближайшие события: " + items.joinToString("; ") { "${it.title} — ${fmt.format(Date(it.triggerAt))}" }
    }
}
