package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Telegram-only UI automation. Requires the user to explicitly enable JARVIS
 * in Android Accessibility settings. It does not control arbitrary apps.
 */
class TelegramAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var step = Step.IDLE
    private var lastActionAt = 0L
    private var startedAt = 0L
    private var lastTarget = ""
    private var lastMessage = ""

    private enum class Step { IDLE, SEARCH, ENTER_TARGET, PICK_RESULT, ENTER_MESSAGE, SEND }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityServiceInfo.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityServiceInfo.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityServiceInfo.TYPE_VIEW_CLICKED or
                AccessibilityServiceInfo.TYPE_VIEW_TEXT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 80
            flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
        }
        startIfPending()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != TELEGRAM_PACKAGE && pkg != TELEGRAM_X_PACKAGE) return

        val pending = TelegramAutomationStore.get(this)
        if (!pending.active || pending.target.isBlank() || pending.message.isBlank()) {
            resetState()
            return
        }
        if (System.currentTimeMillis() - startedAt > 20_000L) {
            TelegramAutomationStore.clear(this)
            resetState()
            return
        }
        if (System.currentTimeMillis() - lastActionAt < 350L) return
        process(pending)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun startIfPending() {
        val pending = TelegramAutomationStore.get(this)
        if (!pending.active || pending.target.isBlank() || pending.message.isBlank()) return
        val packageName = installedTelegramPackage() ?: return
        if (step == Step.IDLE) {
            step = Step.SEARCH
            startedAt = System.currentTimeMillis()
            lastTarget = pending.target
            lastMessage = pending.message
            packageManager.getLaunchIntentForPackage(packageName)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(it)
                touch()
            }
        }
    }

    private fun process(pending: TelegramAutomationStore.Pending) {
        if (pending.target != lastTarget || pending.message != lastMessage) {
            resetState()
            startIfPending()
            return
        }
        val root = rootInActiveWindow ?: return
        when (step) {
            Step.SEARCH -> if (clickSearch(root)) { step = Step.ENTER_TARGET; touch() }
            Step.ENTER_TARGET -> if (setSearchText(root, pending.target)) { step = Step.PICK_RESULT; touch(900) }
            Step.PICK_RESULT -> if (clickMatchingResult(root, candidates(pending.target))) { step = Step.ENTER_MESSAGE; touch(900) }
            Step.ENTER_MESSAGE -> if (setComposerText(root, pending.message)) { step = Step.SEND; touch(500) }
            Step.SEND -> if (clickSend(root)) {
                TelegramAutomationStore.clear(this)
                resetState()
            }
            Step.IDLE -> startIfPending()
        }
    }

    private fun clickSearch(root: AccessibilityNodeInfo): Boolean {
        val ids = listOf(
            "$TELEGRAM_PACKAGE:id/search_button",
            "$TELEGRAM_PACKAGE:id/search",
            "$TELEGRAM_X_PACKAGE:id/search_button"
        )
        ids.asSequence().flatMap { root.findAccessibilityNodeInfosByViewId(it).asSequence() }
            .firstOrNull()?.let { node ->
                if (performClick(node)) return true
            }
        return findClickable(root) { n ->
            val t = normalize(label(n))
            t == "поиск" || t == "search" || t.contains("поиск") || t.contains("search")
        }?.let { performClick(it) } ?: false
    }

    private fun setSearchText(root: AccessibilityNodeInfo, text: String): Boolean {
        val fields = editableNodes(root)
        val field = fields.firstOrNull { n ->
            val hint = normalize(listOfNotNull(n.hintText?.toString(), n.contentDescription?.toString()).joinToString(" "))
            hint.contains("поиск") || hint.contains("search")
        } ?: fields.firstOrNull()
        return field?.let { setText(it, text) } ?: false
    }

    private fun clickMatchingResult(root: AccessibilityNodeInfo, candidates: List<String>): Boolean {
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)
        val normalizedCandidates = candidates.map(::normalize).filter { it.isNotBlank() }
        val scored = nodes.mapNotNull { node ->
            val text = normalize(label(node))
            if (text.isBlank() || !isSafeClickableCandidate(node)) return@mapNotNull null
            val score = when {
                normalizedCandidates.any { text == it } -> 100
                normalizedCandidates.any { text.startsWith(it) } -> 80
                normalizedCandidates.any { text.contains(it) } -> 60
                else -> 0
            }
            if (score == 0) null else node to score
        }.sortedByDescending { it.second }
        return scored.firstOrNull()?.first?.let { performClick(it) } ?: false
    }

    private fun setComposerText(root: AccessibilityNodeInfo, text: String): Boolean {
        val fields = editableNodes(root)
        val field = fields.lastOrNull() ?: return false
        return setText(field, text)
    }

    private fun clickSend(root: AccessibilityNodeInfo): Boolean {
        val ids = listOf(
            "$TELEGRAM_PACKAGE:id/send_button",
            "$TELEGRAM_PACKAGE:id/send",
            "$TELEGRAM_X_PACKAGE:id/send_button"
        )
        ids.asSequence().flatMap { root.findAccessibilityNodeInfosByViewId(it).asSequence() }
            .firstOrNull()?.let { node -> if (performClick(node)) return true }
        return findClickable(root) { n ->
            val t = normalize(label(n))
            t == "отправить" || t == "send" || t.contains("отправить") || t.contains("send")
        }?.let { performClick(it) } ?: false
    }

    private fun setText(node: AccessibilityNodeInfo, text: String): Boolean {
        if (!node.isEditable) return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun editableNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)
        return nodes.filter { it.isEditable && it.className?.toString()?.contains("EditText", true) == true }
    }

    private fun findClickable(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)
        return nodes.firstOrNull { predicate(it) && isSafeClickableCandidate(it) }
    }

    private fun performClick(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        var parent = node.parent
        repeat(3) {
            if (parent?.isClickable == true && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            parent = parent?.parent
        }
        return false
    }

    private fun isSafeClickableCandidate(node: AccessibilityNodeInfo): Boolean = node.isClickable || node.parent?.isClickable == true

    private fun label(node: AccessibilityNodeInfo): String = listOfNotNull(
        node.text?.toString(), node.contentDescription?.toString()
    ).joinToString(" ").trim()

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        out += node
        for (i in 0 until node.childCount) node.getChild(i)?.let { collect(it, out) }
    }

    private fun candidates(raw: String): List<String> {
        val n = normalize(raw)
        val result = linkedSetOf(raw.trim(), n)
        if (n.endsWith("ику")) result += n.dropLast(3) + "ик"
        if (n.endsWith("ку")) result += n.dropLast(2) + "к"
        if (n.endsWith("у") || n.endsWith("ю")) result += n.dropLast(1)
        if (n.endsWith("ке")) result += n.dropLast(2) + "к"
        return result.filter { it.isNotBlank() }
    }

    private fun normalize(s: String): String = s.lowercase(Locale("ru")).trim().removePrefix("@")

    private fun installedTelegramPackage(): String? = listOf(TELEGRAM_PACKAGE, TELEGRAM_X_PACKAGE)
        .firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }

    private fun touch(delay: Long = 650L) {
        lastActionAt = System.currentTimeMillis()
        handler.postDelayed({ rootInActiveWindow?.let { process(TelegramAutomationStore.get(this)) } }, delay)
    }

    private fun resetState() {
        handler.removeCallbacksAndMessages(null)
        step = Step.IDLE
        lastActionAt = 0L
        startedAt = 0L
        lastTarget = ""
        lastMessage = ""
    }

    companion object {
        const val TELEGRAM_PACKAGE = "org.telegram.messenger"
        const val TELEGRAM_X_PACKAGE = "org.thunderdog.challegram"
    }
}
