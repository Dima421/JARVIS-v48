package com.jarvis.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import org.json.JSONObject

/**
 * Production-oriented voice foreground service.
 * One owner of the microphone. Wake-word recognition and command recognition
 * run locally through Vosk; no audio is uploaded by this service.
 */
class JarvisForegroundService : Service() {
    companion object {
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        const val CHANNEL_ID = "jarvis_background"
        const val NOTIFICATION_ID = 3701
        const val SAMPLE_RATE = 16000
        const val WAKE_WORD = "джарвис"
    }

    private val running = AtomicBoolean(false)
    private val executor = Executors.newSingleThreadExecutor()
    private var recorder: AudioRecord? = null
    private var model: Model? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        if (!hasAudioPermission()) {
            stopSelf()
            return
        }
        val types = if (Build.VERSION.SDK_INT >= 34)
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification("Слушаю слово «Джарвис»"), types)
        startWakeWordLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "JARVIS", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun modelDir(): File = File(filesDir, "model-ru")

    private fun startWakeWordLoop() {
        if (!running.compareAndSet(false, true)) return
        executor.execute {
            try {
                val dir = modelDir()
                if (!dir.exists() || dir.listFiles().isNullOrEmpty()) {
                    updateNotification("Нет модели Vosk: помести model-ru в хранилище JARVIS")
                    running.set(false)
                    return@execute
                }
                model = Model(dir.absolutePath)
                val minBuffer = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val bufferSize = maxOf(minBuffer, SAMPLE_RATE * 2)
                val audio = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                recorder = audio
                audio.startRecording()

                val buffer = ShortArray(bufferSize / 2)
                val wakeGrammar = "[\"джарвис\", \"джарвис ноль\", \"[unk]\"]"
                val wake = Recognizer(model, SAMPLE_RATE.toFloat(), wakeGrammar)
                try {
                    while (running.get() && !isDestroyed) {
                        val n = audio.read(buffer, 0, buffer.size)
                        if (n <= 0) continue
                        if (wake.acceptWaveForm(buffer, n)) {
                            val text = extractText(wake.result)
                            if (containsWake(text)) {
                                onWakeDetected()
                                listenForCommand(audio, buffer)
                                wake.reset()
                            }
                        }
                    }
                } finally {
                    wake.close()
                    audio.stop()
                    audio.release()
                    recorder = null
                }
            } catch (t: Throwable) {
                updateNotification("Голосовой модуль остановлен: ${t.javaClass.simpleName}")
            } finally {
                model?.close()
                model = null
                running.set(false)
            }
        }
    }

    private fun listenForCommand(audio: AudioRecord, buffer: ShortArray) {
        updateNotification("Слушаю команду…")
        val command = Recognizer(model, SAMPLE_RATE.toFloat())
        try {
            val deadline = SystemClock.elapsedRealtime() + 7000L
            while (running.get() && SystemClock.elapsedRealtime() < deadline) {
                val n = audio.read(buffer, 0, buffer.size)
                if (n <= 0) continue
                if (command.acceptWaveForm(buffer, n)) {
                    val text = extractText(command.result)
                    if (text.isNotBlank()) {
                        dispatchCommand(text)
                        return
                    }
                }
            }
            val finalText = extractText(command.finalResult)
            if (finalText.isNotBlank()) dispatchCommand(finalText)
        } finally {
            command.close()
            updateNotification("Слушаю слово «Джарвис»")
        }
    }

    private fun extractText(json: String): String = try {
        JSONObject(json).optString("text", "").trim()
    } catch (_: Exception) { "" }

    private fun containsWake(text: String): Boolean =
        text.lowercase().contains(WAKE_WORD)

    private fun onWakeDetected() {
        updateNotification("Джарвис активирован — слушаю команду")
        val i = Intent("com.jarvis.assistant.WAKE_DETECTED").setPackage(packageName)
        sendBroadcast(i)
    }

    private fun dispatchCommand(text: String) {
        val i = Intent("com.jarvis.assistant.VOICE_COMMAND").setPackage(packageName)
            .putExtra("text", text)
        sendBroadcast(i)
        val result = IntentEngine.handle(this, text)
        if (result.handled && result.reply.isNotBlank()) {
            runCatching { speak(result.reply) }
            updateNotification(result.reply.take(120))
        }
    }

    private fun speak(text: String) {
        runCatching {
            // Keep voice feedback short and local; the command itself never leaves the device here.
            val tts = android.speech.tts.TextToSpeech(this) { status ->
                if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                    ttsReadySpeak(text)
                }
            }
        }
    }

    private var activeTts: android.speech.tts.TextToSpeech? = null
    private fun ttsReadySpeak(text: String) {
        activeTts?.stop()
        activeTts?.shutdown()
        activeTts = android.speech.tts.TextToSpeech(this) { status ->
            if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                activeTts?.language = java.util.Locale("ru", "RU")
                activeTts?.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
            }
        }
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, notification(text))
    }

    override fun onDestroy() {
        running.set(false)
        recorder?.let { try { it.stop() } catch (_: Exception) {} }
        executor.shutdownNow()
        super.onDestroy()
    }
}
