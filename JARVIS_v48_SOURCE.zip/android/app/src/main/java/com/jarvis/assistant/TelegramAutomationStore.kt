package com.jarvis.assistant

import android.content.Context

object TelegramAutomationStore {
    private const val PREFS = "jarvis_telegram_auto"
    private const val KEY_TARGET = "target"
    private const val KEY_MESSAGE = "message"
    private const val KEY_ACTIVE = "active"

    data class Pending(val target: String, val message: String, val active: Boolean)

    fun set(context: Context, target: String, message: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TARGET, target.trim())
            .putString(KEY_MESSAGE, message.trim())
            .putBoolean(KEY_ACTIVE, true)
            .apply()
    }

    fun get(context: Context): Pending = with(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)) {
        Pending(getString(KEY_TARGET, "") ?: "", getString(KEY_MESSAGE, "") ?: "", getBoolean(KEY_ACTIVE, false))
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
