package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startIfReady() }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                "com.jarvis.assistant.VOICE_COMMAND" -> {
                    val text = intent.getStringExtra("text") ?: return
                    handleCommand(text, speak = false)
                }
                "com.jarvis.assistant.WAKE_DETECTED" -> web.post { web.evaluateJavascript("window.jarvisWake && window.jarvisWake();", null) }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannels(this)
        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(JarvisBridge(), "JarvisAndroid")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        requestPermissionsIfNeeded()
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(this, receiver, IntentFilter().apply {
            addAction("com.jarvis.assistant.VOICE_COMMAND")
            addAction("com.jarvis.assistant.WAKE_DETECTED")
        }, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStop() {
        runCatching { unregisterReceiver(receiver) }
        super.onStop()
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("JarvisAndroid")
        web.destroy()
        super.onDestroy()
    }

    private fun requestPermissionsIfNeeded() {
        val needed = buildList {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) add(Manifest.permission.RECORD_AUDIO)
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) add(Manifest.permission.SEND_SMS)
            if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) permissions.launch(needed.toTypedArray()) else startIfReady()
    }

    private fun startIfReady() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            ContextCompat.startForegroundService(this, Intent(this, JarvisForegroundService::class.java))
        }
    }

    private fun handleCommand(text: String, speak: Boolean): String {
        val result = IntentEngine.handle(this, text)
        val reply = if (result.handled && result.reply.isNotBlank()) result.reply else "Команда пока не распознана: $text"
        web.post {
            web.evaluateJavascript("window.jarvisVoiceCommand(${js(text)}, ${js(reply)});", null)
        }
        if (speak && result.handled) NotificationHelper.showGeneral(this, "JARVIS", reply)
        return reply
    }

    private fun js(value: String): String = JSONObject.quote(value)

    inner class JarvisBridge {
        @JavascriptInterface fun sendCommand(text: String): String = handleCommand(text, true)

        @JavascriptInterface fun getScheduled(): String {
            val arr = JSONArray()
            val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru"))
            ReminderStore.all(this@MainActivity).filter { it.triggerAt > System.currentTimeMillis() }.sortedBy { it.triggerAt }.forEach {
                arr.put(JSONObject().apply {
                    put("id", it.id); put("title", it.title); put("triggerAt", it.triggerAt); put("date", fmt.format(Date(it.triggerAt))); put("kind", it.kind)
                })
            }
            return arr.toString()
        }

        @JavascriptInterface fun cancelScheduled(id: Long): String {
            ReminderScheduler.cancel(this@MainActivity, id)
            web.post { web.evaluateJavascript("window.jarvisScheduleChanged && window.jarvisScheduleChanged();", null) }
            return "ok"
        }

        @JavascriptInterface fun openNotificationSettings() {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }

        @JavascriptInterface fun openAppSettings() {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface fun openExactAlarmSettings() {
            if (android.os.Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface fun testNotification() {
            NotificationHelper.showGeneral(this@MainActivity, "JARVIS", "Уведомления работают.")
        }

        @JavascriptInterface fun getEmergencyContacts(): String = EmergencyManager.contactsJson(this@MainActivity)

        @JavascriptInterface fun addEmergencyContact(name: String, phone: String): String {
            val result = EmergencyManager.add(this@MainActivity, name, phone)
            web.post { web.evaluateJavascript("window.jarvisEmergencyChanged && window.jarvisEmergencyChanged();", null) }
            return result
        }

        @JavascriptInterface fun removeEmergencyContact(id: Long): String {
            val result = EmergencyManager.remove(this@MainActivity, id)
            web.post { web.evaluateJavascript("window.jarvisEmergencyChanged && window.jarvisEmergencyChanged();", null) }
            return result
        }

        @JavascriptInterface fun activateEmergency(): String = EmergencyManager.activate(this@MainActivity)

        @JavascriptInterface fun openTelegramAutomationSettings() {
            TelegramAutomationServiceHelper.openSettings(this@MainActivity)
        }

        @JavascriptInterface fun telegramAutomationEnabled(): Boolean = TelegramAutomationServiceHelper.enabled(this@MainActivity)

        @JavascriptInterface fun openTelegramLoginHelp() {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://my.telegram.org")))
        }

        @JavascriptInterface fun openTelegram(username: String, message: String): String {
            val clean = username.trim().removePrefix("@").replace(Regex("[^A-Za-z0-9_]+"), "")
            if (clean.isBlank()) return "Не указан Telegram username."
            val encoded = java.net.URLEncoder.encode(message, "UTF-8").replace("+", "%20")
            return try {
                // API не нужен: Telegram официально поддерживает deep link с draft-текстом.
                val tg = Uri.parse("tg://resolve?domain=$clean&text=$encoded")
                val intent = Intent(Intent.ACTION_VIEW, tg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                } else {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$clean?text=$encoded")))
                }
                "Открыл @$clean. Сообщение уже подготовлено — останется нажать «Отправить»."
            } catch (_: Exception) { "Не удалось открыть Telegram." }
        }
    }
}
