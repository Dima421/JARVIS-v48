package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale

/** Local Russian command router. No arbitrary shell execution. */
object IntentEngine {
    data class Result(val handled: Boolean, val reply: String)

    fun handle(context: Context, raw: String): Result {
        val text = raw.lowercase(Locale("ru")).replace(Regex("\\s+"), " ").trim()
        if (text.isBlank()) return Result(false, "")
        parseEmergency(context, text)?.let { return it }
        parseList(context, text)?.let { return it }
        parseCancel(context, text)?.let { return it }
        parseTelegram(context, raw)?.let { return it }
        parseTimer(context, text)?.let { return it }
        parseReminder(context, raw)?.let { return it }
        parseAlarm(context, text)?.let { return it }
        return Result(false, "")
    }

    private fun parseEmergency(context: Context, text: String): Result? {
        val alarmWords = listOf("тревога", "режим тревоги", "аварийный режим", "я в опасности", "мне опасно")
        if (alarmWords.none { text.contains(it) }) return null
        return Result(true, EmergencyManager.activate(context))
    }

    private fun parseList(context: Context, text: String): Result? {
        if (!(text.contains("мои напоминания") || text.contains("что у меня сегодня") || text.contains("что запланировано") || text.contains("покажи напоминания"))) return null
        return Result(true, ReminderScheduler.summary(context))
    }

    private fun parseCancel(context: Context, text: String): Result? {
        if (!(text.contains("отмени") || text.contains("удали") || text.contains("убери"))) return null
        val items = ReminderStore.all(context).filter { it.triggerAt > System.currentTimeMillis() }.sortedBy { it.triggerAt }
        if (items.isEmpty()) return Result(true, "Запланированных событий нет.")
        if (text.contains("все") || text.contains("всё")) {
            items.forEach { ReminderScheduler.cancel(context, it.id) }
            return Result(true, "Все запланированные события отменены.")
        }
        val item = items.firstOrNull()
        ReminderScheduler.cancel(context, item!!.id)
        return Result(true, "Отменил ближайшее событие: ${item.title}.")
    }

    private fun parseTelegram(context: Context, raw: String): Result? {
        val lower = raw.lowercase(Locale("ru"))
        if (!(lower.contains("телеграм") || lower.contains("telegram") || lower.startsWith("напиши ") || lower.startsWith("отправь "))) return null

        val explicit = Regex("(?:телеграм|telegram)\\s+(?:напиши|написать|отправь|сообщение)\\s+(?:пользователю|человеку)?\\s*@?([A-Za-z0-9_]{3,64})\\s+(.+)", RegexOption.IGNORE_CASE).find(raw)
            ?: Regex("(?:напиши|отправь)\\s+(?:в\\s+)?(?:телеграм|telegram)\\s+@?([A-Za-z0-9_]{3,64})\\s+(.+)", RegexOption.IGNORE_CASE).find(raw)

        if (explicit != null) {
            val username = explicit.groupValues[1].removePrefix("@")
            val message = explicit.groupValues[2].trim()
            TelegramAutomationStore.set(context, username, message)
            return if (TelegramAutomationServiceHelper.enabled(context)) {
                TelegramAutomationServiceHelper.launchTelegram(context)
                Result(true, "Открываю Telegram и отправляю сообщение @${username}.")
            } else {
                openTelegramDraft(context, username, message)
                Result(true, "Открыл Telegram с готовым сообщением. Включи автоматическую отправку JARVIS в настройках доступности — тогда отправка будет без нажатия.")
            }
        }

        val byName = Regex("(?:напиши|отправь)\\s+(?:в\\s+)?(?:телеграм|telegram)?\\s*(?:контакту|человеку|пользователю)?\\s*([А-Яа-яЁёA-Za-z0-9_@-]{2,64})\\s+(.+)", RegexOption.IGNORE_CASE).find(raw)
            ?: return Result(true, "Скажи, например: «Джарвис, напиши Шатрику привет» или «Джарвис, напиши @username привет».")
        val target = byName.groupValues[1].trim().removePrefix("@")
        val message = byName.groupValues[2].trim()
        if (target.isBlank() || message.isBlank()) return Result(true, "Не понял получателя или текст сообщения.")
        TelegramAutomationStore.set(context, target, message)
        return if (TelegramAutomationServiceHelper.enabled(context)) {
            TelegramAutomationServiceHelper.launchTelegram(context)
            Result(true, "Открываю Telegram, нахожу $target и отправляю сообщение автоматически.")
        } else {
            // Fallback: if the target is a username, use Telegram's official draft deep link.
            if (target.matches(Regex("[A-Za-z0-9_]{3,64}"))) openTelegramDraft(context, target, message)
            Result(true, "Для автоматической отправки нужно один раз включить службу доступности JARVIS. После этого я смогу находить контакты по имени и отправлять сообщение сам.")
        }
    }

    private fun openTelegramDraft(context: Context, username: String, message: String) {
        val encoded = URLEncoder.encode(message, "UTF-8").replace("+", "%20")
        try {
            val tg = Uri.parse("tg://resolve?domain=$username&text=$encoded")
            context.startActivity(Intent(Intent.ACTION_VIEW, tg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$username?text=$encoded")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    private fun parseTimer(context: Context, text: String): Result? {
        if (!text.contains("таймер")) return null
        val h = Regex("(\\d+)\\s*(час|часа|часов)").find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0
        val m = Regex("(\\d+)\\s*(мин|минута|минут|минуты)").find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0
        val s = Regex("(\\d+)\\s*(сек|секунда|секунд|секунды)").find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0
        val total = h * 3600 + m * 60 + s
        if (total <= 0) return Result(true, "Скажи длительность таймера, например: «таймер на 10 минут».")
        ReminderScheduler.schedule(context, "Таймер на ${formatDuration(total)} завершён.", System.currentTimeMillis() + total * 1000, "timer")
        return Result(true, "Таймер поставлен на ${formatDuration(total)}.")
    }

    private fun parseReminder(context: Context, raw: String): Result? {
        val lower = raw.lowercase(Locale("ru"))
        if (!lower.contains("напомни")) return null
        val timeMatch = Regex("(?:в|на)\\s*(\\d{1,2})(?::(\\d{2}))?").find(lower)
        val time = if (timeMatch != null) LocalTime.of(timeMatch.groupValues[1].toInt(), timeMatch.groupValues.getOrNull(2)?.takeIf { it.isNotBlank() }?.toInt() ?: 0) else null
        val date = when {
            "послезавтра" in lower -> LocalDate.now().plusDays(2)
            "завтра" in lower -> LocalDate.now().plusDays(1)
            "через неделю" in lower -> LocalDate.now().plusWeeks(1)
            else -> LocalDate.now()
        }
        val duration = Regex("через\\s+(\\d+)\\s*(минут|мин|час|часа|часов|день|дня|дней|недел|неделю)").find(lower)
        val trigger = if (duration != null) {
            val n = duration.groupValues[1].toLong(); val unit = duration.groupValues[2]
            val seconds = when { unit.startsWith("мин") -> n * 60; unit.startsWith("час") -> n * 3600; unit.startsWith("д") -> n * 86400; else -> n * 604800 }
            System.currentTimeMillis() + seconds * 1000
        } else {
            val dt = LocalDateTime.of(date, time ?: LocalTime.of(9, 0))
            val candidate = dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            if (candidate <= System.currentTimeMillis() && time != null && date == LocalDate.now()) candidate + 86400000 else candidate
        }
        if (trigger <= System.currentTimeMillis()) return Result(true, "Укажи будущее время для напоминания.")
        val title = raw.replaceFirst(Regex("^.*?напомни(?: мне)?\\s*", RegexOption.IGNORE_CASE), "").trim().ifBlank { "Напоминание JARVIS" }
        val offsets = listOf(30L * 86400000, 7L * 86400000, 2L * 86400000, 1L * 86400000, 3L * 3600000, 1L * 3600000)
        val labels = listOf("за 1 месяц", "за 1 неделю", "за 2 дня", "за 1 день", "за 3 часа", "за 1 час")
        var count = 0
        offsets.zip(labels).forEach { (offset, label) ->
            val at = trigger - offset
            if (at > System.currentTimeMillis()) { ReminderScheduler.schedule(context, "$title ($label)", at, "reminder"); count++ }
        }
        ReminderScheduler.schedule(context, title, trigger, "reminder")
        return Result(true, "Напоминание поставлено. Я напомню $count раз до события и в момент события.")
    }

    private fun parseAlarm(context: Context, text: String): Result? {
        if (!(text.contains("будильник") || text.contains("разбуди меня"))) return null
        val m = Regex("(?:в|на)\\s*(\\d{1,2})(?::(\\d{2}))?").find(text) ?: return Result(true, "Скажи время, например: «будильник на 7:30».")
        val h = m.groupValues[1].toInt(); val min = m.groupValues.getOrNull(2)?.takeIf { it.isNotBlank() }?.toInt() ?: 0
        var date = LocalDate.now(); if ("завтра" in text) date = date.plusDays(1)
        var trigger = LocalDateTime.of(date, LocalTime.of(h, min)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (trigger <= System.currentTimeMillis()) trigger += 86400000
        ReminderScheduler.schedule(context, "Будильник на ${"%02d:%02d".format(h, min)}", trigger, "alarm")
        return Result(true, "Будильник поставлен на %02d:%02d.".format(h, min))
    }

    private fun formatDuration(seconds: Long): String {
        val h = seconds / 3600; val m = (seconds % 3600) / 60; val s = seconds % 60
        return buildString { if (h > 0) append("$h ч "); if (m > 0) append("$m мин "); if (s > 0) append("$s сек") }.trim()
    }
}
