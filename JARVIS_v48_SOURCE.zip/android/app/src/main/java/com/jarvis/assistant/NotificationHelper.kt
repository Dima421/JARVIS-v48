package com.jarvis.assistant

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationHelper {
    const val CHANNEL_REMINDERS = "jarvis_reminders"
    const val CHANNEL_GENERAL = "jarvis_general"

    fun createChannels(context: Context) {
        if (android.os.Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_REMINDERS, "Напоминания и будильники", NotificationManager.IMPORTANCE_HIGH).apply { description = "Таймеры, будильники и голосовые напоминания JARVIS" })
        nm.createNotificationChannel(NotificationChannel(CHANNEL_GENERAL, "JARVIS", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "Ответы и события JARVIS" })
    }

    fun show(context: Context, title: String, text: String, id: Int = (System.currentTimeMillis() and 0x7fffffff).toInt()) {
        createChannels(context)
        if (android.os.Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text)).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER).build()
        NotificationManagerCompat.from(context).notify(id, notification)
    }

    fun showGeneral(context: Context, title: String, text: String) {
        createChannels(context)
        if (android.os.Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = NotificationCompat.Builder(context, CHANNEL_GENERAL)
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text)).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        NotificationManagerCompat.from(context).notify((System.currentTimeMillis() and 0x7fffffff).toInt(), notification)
    }
}
