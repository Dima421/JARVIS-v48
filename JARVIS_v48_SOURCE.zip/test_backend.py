import os, tempfile
os.environ['JARVIS_HOME'] = tempfile.mkdtemp(prefix='jarvis-test-')
from fastapi.testclient import TestClient
from backend import app

c = TestClient(app)
r = c.get('/api/health')
assert r.status_code == 200 and r.json()['ok'] is True
r = c.post('/api/contacts', json={'name':'Test','phone':'+31123456789','enabled':True})
assert r.status_code == 200
cid = r.json()['id']
r = c.get('/api/contacts')
assert any(x['id']==cid for x in r.json())
r = c.put('/api/alarm/settings', json={'enabled':True,'send_location':True,'message':'ALERT','repeat_minutes':30,'location_refresh_minutes':10,'send_recovery_message':True,'recovery_message':'OK'})
assert r.status_code == 200 and r.json()['message']=='ALERT'
r = c.delete(f'/api/contacts/{cid}')
assert r.status_code == 200
print('JARVIS backend tests: OK')
