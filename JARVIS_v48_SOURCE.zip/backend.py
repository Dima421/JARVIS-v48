#!/usr/bin/env python3
from __future__ import annotations

import asyncio, json, os, re, sqlite3, subprocess, time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

APP = Path(os.environ.get("JARVIS_HOME", str(Path.home() / "jarvis")))
DB = APP / "jarvis_memory.db"
MODEL = APP / "model-ru"
STATIC = Path(__file__).parent / "static"
ROOT_ENABLED = os.environ.get("JARVIS_ROOT", "0") == "1"

ALARM: dict[str, Any] = {"active": False, "started_at": None, "reason": "", "location": None, "sent_to": []}
ALARM_TASK: asyncio.Task | None = None
ALARM_SEND_LOCK = asyncio.Lock()
WS_CLIENTS: set[WebSocket] = set()

app = FastAPI(title="JARVIS", version="38.0")
app.mount("/static", StaticFiles(directory=STATIC), name="static")


class CommandIn(BaseModel):
    text: str = Field(min_length=1, max_length=1000)


class NoteIn(BaseModel):
    content: str = Field(min_length=1, max_length=4000)


class RoutineIn(BaseModel):
    name: str


class ContactIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    phone: str = Field(min_length=7, max_length=30)
    enabled: bool = True


class ContactUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    phone: str | None = Field(default=None, min_length=7, max_length=30)
    enabled: bool | None = None


class AlarmSettingsIn(BaseModel):
    enabled: bool = True
    send_location: bool = True
    message: str = Field(default="Я в опасности. JARVIS активировал режим тревоги. Я на связи. Если я не отвечаю, пожалуйста, свяжитесь со мной.", max_length=500)
    repeat_minutes: int = Field(default=30, ge=0, le=1440)
    location_refresh_minutes: int = Field(default=10, ge=0, le=1440)
    send_recovery_message: bool = True
    recovery_message: str = Field(default="JARVIS: режим тревоги отменён. Со мной всё в порядке.", max_length=500)


def db():
    APP.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
    con.execute("CREATE TABLE IF NOT EXISTS contacts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
    con.execute("CREATE TABLE IF NOT EXISTS alarm_settings (id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 1, send_location INTEGER NOT NULL DEFAULT 1, message TEXT NOT NULL, repeat_minutes INTEGER NOT NULL DEFAULT 30, location_refresh_minutes INTEGER NOT NULL DEFAULT 10, send_recovery_message INTEGER NOT NULL DEFAULT 1, recovery_message TEXT NOT NULL DEFAULT 'JARVIS: режим тревоги отменён. Со мной всё в порядке.')")
    # Migrate v33 databases without losing existing settings.
    cols={r[1] for r in con.execute("PRAGMA table_info(alarm_settings)").fetchall()}
    for name, ddl in [("location_refresh_minutes", "INTEGER NOT NULL DEFAULT 10"), ("send_recovery_message", "INTEGER NOT NULL DEFAULT 1"), ("recovery_message", "TEXT NOT NULL DEFAULT 'JARVIS: режим тревоги отменён. Со мной всё в порядке.'")]:
        if name not in cols: con.execute(f"ALTER TABLE alarm_settings ADD COLUMN {name} {ddl}")
    con.execute("INSERT OR IGNORE INTO alarm_settings(id,enabled,send_location,message,repeat_minutes,location_refresh_minutes,send_recovery_message,recovery_message) VALUES(1,1,1,?,30,10,1,?)", ("Я в опасности. JARVIS активировал режим тревоги. Я на связи. Если я не отвечаю, пожалуйста, свяжитесь со мной.", "JARVIS: режим тревоги отменён. Со мной всё в порядке."))
    con.commit()
    return con


def run(args: list[str], timeout: int = 15, root: bool = False) -> tuple[int, str, str]:
    if root:
        if not ROOT_ENABLED:
            return 126, "", "Root bridge disabled"
        args = ["su", "-c", "--", *args]
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except Exception as e:
        return 1, "", str(e)


def speak(text: str):
    text = re.sub(r"\s+", " ", str(text)).strip()
    if text:
        run(["termux-tts-speak", "-l", "ru-RU", "-r", "0.95", text], 20)


def strip_wake(text: str) -> str:
    for w in ("джарвис", "шатрик", "шарик", "шатрикс"):
        text = re.sub(rf"\b{re.escape(w)}\b", " ", text, flags=re.I)
    return re.sub(r"\s+", " ", text).strip()


def get_alarm_settings() -> dict[str, Any]:
    con = db(); row = con.execute("SELECT enabled,send_location,message,repeat_minutes,location_refresh_minutes,send_recovery_message,recovery_message FROM alarm_settings WHERE id=1").fetchone(); con.close()
    return {"enabled": bool(row[0]), "send_location": bool(row[1]), "message": row[2], "repeat_minutes": int(row[3]), "location_refresh_minutes": int(row[4]), "send_recovery_message": bool(row[5]), "recovery_message": row[6]}


def save_alarm_settings(s: AlarmSettingsIn) -> dict[str, Any]:
    con = db(); con.execute("UPDATE alarm_settings SET enabled=?,send_location=?,message=?,repeat_minutes=?,location_refresh_minutes=?,send_recovery_message=?,recovery_message=? WHERE id=1", (int(s.enabled), int(s.send_location), s.message.strip(), s.repeat_minutes, s.location_refresh_minutes, int(s.send_recovery_message), s.recovery_message.strip())); con.commit(); con.close(); return get_alarm_settings()


def normalize_phone(phone: str) -> str | None:
    phone = phone.strip()
    if not re.fullmatch(r"\+?[0-9 ()-]{7,30}", phone): return None
    return re.sub(r"[ ()-]", "", phone)


def contacts() -> list[dict[str, Any]]:
    con = db(); rows = con.execute("SELECT id,name,phone,enabled,created_at FROM contacts ORDER BY id DESC").fetchall(); con.close()
    return [{**dict(r), "enabled": bool(r["enabled"])} for r in rows]


def add_contact(c: ContactIn) -> dict[str, Any]:
    phone = normalize_phone(c.phone)
    if not phone: raise HTTPException(400, "Некорректный номер телефона")
    con = db(); cur = con.execute("INSERT INTO contacts(name,phone,enabled) VALUES(?,?,?)", (c.name.strip(), phone, int(c.enabled))); con.commit(); row = con.execute("SELECT id,name,phone,enabled,created_at FROM contacts WHERE id=?", (cur.lastrowid,)).fetchone(); con.close()
    return {**dict(row), "enabled": bool(row["enabled"])}


def update_contact(contact_id: int, c: ContactUpdate) -> dict[str, Any]:
    fields=[]; vals=[]
    if c.name is not None: fields.append("name=?"); vals.append(c.name.strip())
    if c.phone is not None:
        phone=normalize_phone(c.phone)
        if not phone: raise HTTPException(400,"Некорректный номер телефона")
        fields.append("phone=?"); vals.append(phone)
    if c.enabled is not None: fields.append("enabled=?"); vals.append(int(c.enabled))
    if not fields: raise HTTPException(400,"Нет изменений")
    vals.append(contact_id); con=db(); cur=con.execute(f"UPDATE contacts SET {','.join(fields)} WHERE id=?", vals); con.commit(); row=con.execute("SELECT id,name,phone,enabled,created_at FROM contacts WHERE id=?",(contact_id,)).fetchone(); con.close()
    if not cur.rowcount or row is None: raise HTTPException(404,"Контакт не найден")
    return {**dict(row),"enabled":bool(row["enabled"])}


def delete_contact(contact_id: int):
    con=db(); cur=con.execute("DELETE FROM contacts WHERE id=?",(contact_id,)); con.commit(); con.close()
    if not cur.rowcount: raise HTTPException(404,"Контакт не найден")
    return {"ok": True}


def get_location() -> dict[str, Any] | None:
    # Termux:API asks Android for the current location; no location is stored in the DB.
    rc, out, err = run(["termux-location", "-p", "gps", "-r", "once"], 20)
    if rc != 0:
        rc, out, err = run(["termux-location", "-p", "network", "-r", "once"], 20)
    if rc != 0: return None
    try:
        d=json.loads(out); lat=d.get("latitude"); lon=d.get("longitude")
        if lat is None or lon is None: return None
        return {"latitude": float(lat), "longitude": float(lon), "accuracy": d.get("accuracy"), "timestamp": d.get("timestamp"), "maps_url": f"https://maps.google.com/?q={lat},{lon}"}
    except Exception:
        return None


def build_alarm_message(location: dict[str, Any] | None) -> str:
    s=get_alarm_settings(); msg=s["message"].strip()
    if location and s["send_location"]:
        msg += f"\n\nМоя геолокация: {location['maps_url']}"
        if location.get("accuracy") is not None: msg += f"\nТочность: примерно {location['accuracy']} м."
    return msg


def send_alarm_sms(contact: dict[str, Any], message: str) -> tuple[bool, str]:
    rc, _, err = run(["termux-sms-send", "-n", contact["phone"], message], 30)
    return rc == 0, err or "ошибка"


async def notify_alarm_contacts() -> tuple[list[str], dict[str, Any] | None]:
    async with ALARM_SEND_LOCK:
        settings=get_alarm_settings()
        if not settings["enabled"]: return [], None
        enabled=[c for c in contacts() if c["enabled"]]
        location=await asyncio.to_thread(get_location) if settings["send_location"] else None
        message=build_alarm_message(location)
        sent=[]
        for c in enabled:
            ok,_=await asyncio.to_thread(send_alarm_sms,c,message)
            if ok: sent.append(c["name"])
        return sent, location


async def broadcast_alarm():
    payload={"type":"alarm","active":ALARM["active"],"reason":ALARM["reason"],"sent_to":ALARM["sent_to"],"location":ALARM["location"]}
    dead=[]
    for ws in list(WS_CLIENTS):
        try: await ws.send_json(payload)
        except Exception: dead.append(ws)
    for ws in dead: WS_CLIENTS.discard(ws)


async def send_recovery_sms():
    settings=get_alarm_settings()
    if not settings["send_recovery_message"]: return []
    msg=settings["recovery_message"]
    sent=[]
    for c in [x for x in contacts() if x["enabled"]]:
        ok,_=await asyncio.to_thread(send_alarm_sms,c,msg)
        if ok: sent.append(c["name"])
    return sent


async def _alarm_loop():
    # No flashlight: alarm is visual/UI + vibration + TTS + configured contacts.
    while ALARM["active"]:
        await asyncio.to_thread(run, ["termux-vibrate", "-d", "700"], 5)
        await asyncio.to_thread(speak, "Тревога активна. Я на связи.")
        settings=get_alarm_settings()
        repeat=settings["repeat_minutes"]
        refresh=settings["location_refresh_minutes"]
        if refresh > 0:
            await asyncio.sleep(max(30, refresh * 60))
            if ALARM["active"]:
                sent, location = await notify_alarm_contacts()
                ALARM["sent_to"].extend(x for x in sent if x not in ALARM["sent_to"])
                if location: ALARM["location"]=location
                await broadcast_alarm()
        else:
            await asyncio.sleep(max(30, repeat * 60) if repeat > 0 else 30)
            if ALARM["active"] and repeat > 0:
                sent, location = await notify_alarm_contacts()
                ALARM["sent_to"].extend(x for x in sent if x not in ALARM["sent_to"])
                if location: ALARM["location"]=location
                await broadcast_alarm()


async def alarm_start(reason: str = "") -> dict[str, Any]:
    global ALARM_TASK
    if ALARM["active"]: return {"active": True, "message": "Режим тревоги уже активен.", "alarm": ALARM.copy()}
    ALARM["active"]=True; ALARM["started_at"]=time.time(); ALARM["reason"]=reason[:500]; ALARM["sent_to"]=[]; ALARM["location"]=None
    sent, location = await notify_alarm_contacts()
    ALARM["sent_to"]=sent; ALARM["location"]=location
    ALARM_TASK=asyncio.create_task(_alarm_loop())
    await broadcast_alarm()
    msg="Режим тревоги активирован. Я на связи."
    if sent: msg += " Сообщение отправлено: " + ", ".join(sent) + "."
    elif get_alarm_settings()["enabled"] and contacts(): msg += " Не удалось отправить сообщения контактам."
    elif get_alarm_settings()["enabled"]: msg += " В настройках тревоги нет активных контактов."
    return {"active":True,"message":msg,"alarm":ALARM.copy()}


async def alarm_stop() -> dict[str, Any]:
    global ALARM_TASK
    ALARM["active"]=False; ALARM["started_at"]=None; ALARM["reason"]=""; ALARM["location"]=None
    if ALARM_TASK and not ALARM_TASK.done():
        ALARM_TASK.cancel()
        try: await ALARM_TASK
        except asyncio.CancelledError: pass
    ALARM_TASK=None
    recovery=await send_recovery_sms()
    await broadcast_alarm()
    msg="Режим тревоги выключен."
    if recovery: msg += " Контакты уведомлены: " + ", ".join(recovery) + "."
    return {"active":False,"message":msg,"alarm":ALARM.copy()}


async def alarm_toggle_from_command(text: str) -> str | None:
    t=strip_wake(text.lower())
    if any(x in t for x in ("отмена тревоги","выключи тревогу","отбой тревоги","сними тревогу")): return (await alarm_stop())["message"]
    if any(x in t for x in ("режим тревоги","включи тревогу","активируй тревогу","тревога","сирена")): return (await alarm_start(t))["message"]
    return None


def battery() -> str:
    rc,out,_=run(["termux-battery-status"])
    if rc!=0:return "Не удалось получить состояние батареи."
    try:
        d=json.loads(out); return f"Заряд батареи {d.get('percentage','?')} процентов. Состояние: {d.get('status','неизвестно')}."
    except Exception:return "Не удалось прочитать данные батареи."


def torch(on: bool) -> str:
    rc,_,err=run(["termux-torch","on" if on else "off"])
    return ("Фонарик включён." if on else "Фонарик выключен.") if rc==0 else f"Не удалось управлять фонариком: {err or 'ошибка'}."


def launch_app(target: str) -> str:
    target=target.strip()
    if not re.fullmatch(r"[A-Za-z0-9_\.]+",target): return "Некорректное имя приложения или package name."
    rc,_,_=run(["monkey","-p",target,"-c","android.intent.category.LAUNCHER","1"],15)
    return f"Запускаю {target}." if rc==0 else f"Не удалось запустить {target}."


def music(action: str) -> str:
    key={"play":"KEYCODE_MEDIA_PLAY","pause":"KEYCODE_MEDIA_PAUSE","next":"KEYCODE_MEDIA_NEXT","prev":"KEYCODE_MEDIA_PREVIOUS"}.get(action)
    if not key:return "Неизвестная команда музыки."
    rc,_,_=run(["input","keyevent",key]); return "Готово." if rc==0 else "Не удалось управлять воспроизведением."


def volume(direction: str) -> str:
    key="KEYCODE_VOLUME_UP" if direction=="up" else "KEYCODE_VOLUME_DOWN"; rc,_,_=run(["input","keyevent",key]); return "Громкость изменена." if rc==0 else "Не удалось изменить громкость."


def save_note(text: str) -> str:
    con=db(); con.execute("INSERT INTO notes(content) VALUES(?)",(text,)); con.commit(); con.close(); return f"Записал: {text}."


def routine(name: str) -> list[str]:
    n=name.lower().strip()
    if n in {"режим авто","авторежим","авто"}: return ["bluetooth_on","launch:ru.yandex.yandexnavi","launch:ru.yandex.music"]
    raise ValueError("Неизвестный сценарий")


def execute_action(action: str) -> str:
    if action=="bluetooth_on":
        rc,_,_=run(["termux-bluetooth-enable","true"]); return "Bluetooth включён." if rc==0 else "Не удалось включить Bluetooth."
    if action.startswith("launch:"): return launch_app(action.split(":",1)[1])
    if action=="music_play": return music("play")
    raise ValueError("Недопустимое действие сценария")


def process(text: str) -> str:
    t=strip_wake(text.lower())
    if not t:return "Слушаю."
    if any(x in t for x in ("режим тревоги","включи тревогу","тревога","сирена","отмена тревоги","выключи тревогу","отбой тревоги","сними тревогу")): return "__ALARM__"
    if "фонарик" in t:return torch("выключ" not in t)
    if "батар" in t or "заряд" in t:return battery()
    if "увеличь громкость" in t or "громче" in t:return volume("up")
    if "уменьши громкость" in t or "тише" in t:return volume("down")
    if "пауза" in t:return music("pause")
    if "следующий трек" in t:return music("next")
    if "предыдущий трек" in t:return music("prev")
    if "включи музыку" in t or "продолжи музыку" in t:return music("play")
    if t.startswith("запусти "):return launch_app(t[8:].strip())
    if t.startswith("открой "):return launch_app(t[7:].strip())
    if any(x in t for x in ("запиши","запомни","сделай заметку")):
        s=re.sub(r"\b(запиши|запомни|сделай заметку)\b","",t).strip(); return save_note(s) if s else "Что именно записать?"
    if t in {"привет","здравствуй","здарова","хай"}:return "Здравия желаю. Я слушаю."
    if t in {"остановись","выключись","спать","хватит"}:return "__STOP__"
    return "Команду понял, но это действие пока не добавлено в безопасный список."


@app.get("/")
async def index(): return FileResponse(STATIC/"index.html")

@app.get("/api/health")
async def health(): return {"ok":True,"root_bridge":ROOT_ENABLED,"model":MODEL.exists(),"alarm":ALARM["active"]}

@app.get("/api/notes")
async def notes():
    con=db(); rows=con.execute("SELECT id,content,created_at FROM notes ORDER BY id DESC LIMIT 100").fetchall(); con.close(); return [dict(r) for r in rows]

@app.post("/api/notes")
async def add_note(item: NoteIn): return {"answer":save_note(item.content)}

@app.get("/api/contacts")
async def get_contacts(): return contacts()

@app.post("/api/contacts")
async def create_contact(item: ContactIn): return add_contact(item)

@app.patch("/api/contacts/{contact_id}")
async def patch_contact(contact_id:int,item:ContactUpdate): return update_contact(contact_id,item)

@app.delete("/api/contacts/{contact_id}")
async def remove_contact(contact_id:int): return delete_contact(contact_id)

@app.get("/api/alarm/settings")
async def alarm_settings(): return get_alarm_settings()

@app.put("/api/alarm/settings")
async def put_alarm_settings(item:AlarmSettingsIn): return save_alarm_settings(item)

@app.get("/api/alarm/location")
async def current_location():
    loc=await asyncio.to_thread(get_location)
    if not loc: raise HTTPException(503,"Не удалось получить геолокацию. Проверь разрешение Termux:API.")
    return loc

@app.post("/api/command")
async def command(item:CommandIn):
    alarm_answer=await alarm_toggle_from_command(item.text)
    if alarm_answer is not None: return {"answer":alarm_answer,"alarm":ALARM.copy()}
    answer=await asyncio.to_thread(process,item.text)
    if answer!="__STOP__": await asyncio.to_thread(speak,answer)
    return {"answer":answer,"alarm":ALARM.copy()}

@app.post("/api/routines")
async def run_routine(item:RoutineIn):
    try: actions=routine(item.name)
    except ValueError as e: raise HTTPException(404,str(e))
    results=[await asyncio.to_thread(execute_action,a) for a in actions]; answer=" ".join(results); await asyncio.to_thread(speak,answer); return {"answer":answer,"actions":actions}

@app.get("/api/alarm")
async def alarm_status(): return ALARM.copy()

@app.post("/api/alarm/start")
async def alarm_start_api(): return await alarm_start("UI")

@app.post("/api/alarm/stop")
async def alarm_stop_api(): return await alarm_stop()

@app.post("/api/voice/transcribe")
async def transcribe_voice(file: bytes = b""):
    # Kept as a native-compatible HTTP seam. The APK can send PCM/WAV here later.
    if not file: raise HTTPException(400, "Пустая аудиозапись")
    try:
        import tempfile, wave, vosk
    except ImportError: raise HTTPException(503, "Vosk не установлен")
    tmp=APP/"voice_api.wav"; tmp.write_bytes(file)
    try:
        with wave.open(str(tmp),"rb") as wf:
            if wf.getnchannels()!=1 or wf.getsampwidth()!=2: raise HTTPException(400,"Нужен mono PCM WAV 16-bit")
            rec=vosk.KaldiRecognizer(vosk.Model(str(MODEL)), wf.getframerate())
            while True:
                data=wf.readframes(4000)
                if not data: break
                rec.AcceptWaveform(data)
            text=json.loads(rec.FinalResult()).get("text","").strip()
        if not text: return {"text":"","wake":False}
        wake=any(re.search(rf"\b{re.escape(w)}\b",text,re.I) for w in ("джарвис","шатрик","шарик","шатрикс"))
        answer=None
        if wake:
            answer=await alarm_toggle_from_command(text)
            if answer is None: answer=await asyncio.to_thread(process,text)
        return {"text":text,"wake":wake,"answer":answer,"alarm":ALARM.copy()}
    finally:
        tmp.unlink(missing_ok=True)


@app.websocket("/ws")
async def websocket(ws:WebSocket):
    await ws.accept(); WS_CLIENTS.add(ws)
    await ws.send_json({"type":"state","state":"idle"}); await ws.send_json({"type":"alarm","active":ALARM["active"],"reason":ALARM["reason"],"sent_to":ALARM["sent_to"],"location":ALARM["location"]})
    try:
        while True:
            msg=await ws.receive_json(); typ=msg.get("type")
            if typ=="command":
                text=str(msg.get("text",""))[:1000]; await ws.send_json({"type":"state","state":"processing"}); answer=await alarm_toggle_from_command(text)
                if answer is not None:
                    await ws.send_json({"type":"assistant","text":answer}); await ws.send_json({"type":"alarm","active":ALARM["active"],"reason":ALARM["reason"],"sent_to":ALARM["sent_to"],"location":ALARM["location"]})
                else:
                    answer=await asyncio.to_thread(process,text); await ws.send_json({"type":"assistant","text":answer})
                    if answer!="__STOP__": await asyncio.to_thread(speak,answer)
                await ws.send_json({"type":"state","state":"idle"})
            elif typ=="alarm_start":
                result=await alarm_start("UI"); await ws.send_json({"type":"alarm","active":True,"reason":ALARM["reason"],"sent_to":ALARM["sent_to"],"location":ALARM["location"]}); await ws.send_json({"type":"assistant","text":result["message"]})
            elif typ=="alarm_stop":
                result=await alarm_stop(); await ws.send_json({"type":"alarm","active":False,"reason":"","sent_to":ALARM["sent_to"],"location":None}); await ws.send_json({"type":"assistant","text":result["message"]})
            elif typ=="ping": await ws.send_json({"type":"pong","ts":time.time()})
    except WebSocketDisconnect: pass
    finally: WS_CLIENTS.discard(ws)
