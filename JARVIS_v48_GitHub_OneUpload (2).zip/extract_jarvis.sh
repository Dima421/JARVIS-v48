#!/bin/sh
set -e
unzip -o JARVIS_v48_GitHub_OneUpload.zip
cp -R JARVIS_v48/. .
echo 'JARVIS v48 extracted.'
